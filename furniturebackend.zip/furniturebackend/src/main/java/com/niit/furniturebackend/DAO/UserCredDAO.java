package com.niit.furniturebackend.DAO;

import java.util.List;

import com.niit.furniturebackend.model.UserCred;

public interface UserCredDAO {
	boolean createUserCred(UserCred usercred);
	   boolean updateUserCred(UserCred usercred);
	   boolean deleteUserCred(UserCred usercred);
	   List<UserCred> selectAllUser();
	   UserCred selectOneUser(int useremailid);
	   
}
