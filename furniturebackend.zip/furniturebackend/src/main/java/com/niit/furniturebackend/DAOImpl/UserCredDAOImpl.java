package com.niit.furniturebackend.DAOImpl;

import java.util.List;

import org.hibernate.SessionFactory;
import org.springframework.beans.factory.annotation.Autowired;

import com.niit.furniturebackend.DAO.UserCredDAO;
import com.niit.furniturebackend.model.UserCred;


public class UserCredDAOImpl implements UserCredDAO {

	
	@Autowired
	SessionFactory sessionFactory;
	public boolean createUserCred(UserCred usercred) {
		// TODO Auto-generated method stub
		try {
			sessionFactory.getCurrentSession().save(usercred);
			return true;
			
		}
		catch(Exception e){
			System.out.println(e.getMessage());
			return false;
		}
	}

	@Override
	public boolean updateUserCred(UserCred usercred) {
		// TODO Auto-generated method stub
		try {
			sessionFactory.getCurrentSession().update(usercred);
			return true;
			
		}
		catch(Exception e){
			System.out.println(e.getMessage());
			return false;
			
		}
	}

	@Override
	public boolean deleteUserCred(UserCred usercred) {
		// TODO Auto-generated method stub
		try {
			sessionFactory.getCurrentSession().delete(usercred);
			return true;
			
		}
		catch(Exception e){
			System.out.println(e.getMessage());
			return false;
			
		}
	}
	
	public List<UserCred> selectAllUser() {
		// TODO Auto-generated method stub
		try {
			return sessionFactory.getCurrentSession().createQuery("from UserCred").list();
		}
		catch(Exception e) {
			System.out.println(e.getMessage());
			return null;
	}
	}

	@Override
	public UserCred selectOneUser(int useremailid) {
		try {
			return (UserCred)sessionFactory.getCurrentSession().createQuery("from UserCred where emailid="+useremailid).uniqueResult();
		}
		catch(Exception e) {
			System.out.println(e.getMessage());
			return null;
	}
	}
	

}
