package com.niit.furniturebackend.DAOImpl;

import java.util.List;

import org.hibernate.SessionFactory;
import org.springframework.beans.factory.annotation.Autowired;

import com.niit.furniturebackend.DAO.UserDetailsDAO;
import com.niit.furniturebackend.model.UserDetails;

public  class UserDetailsDAOImpl implements UserDetailsDAO
{

	@Autowired
	SessionFactory sessionFactory;
	public boolean createUserDetails(UserDetails userdetails) {
		// TODO Auto-generated method stub
		try {
			sessionFactory.getCurrentSession().save(userdetails);
			return true;
			
		}
		catch(Exception e){
			System.out.println(e.getMessage());
			return false;
			
		}
	}

	@Override
	public boolean updateUserDetails(UserDetails userdetails) {
		// TODO Auto-generated method stub
		try {
			sessionFactory.getCurrentSession().update(userdetails);
			return true;
			
		}
		catch(Exception e){
			System.out.println(e.getMessage());
			return false;
			
		}
	}

	@Override
	public boolean deteleUserDetails(UserDetails userdetails) {
		// TODO Auto-generated method stub
		try {
			sessionFactory.getCurrentSession().delete(userdetails);
			return true;
			
		}
		catch(Exception e){
			System.out.println(e.getMessage());
			return false;
			
		}
	}

	@Override
	public List<UserDetails> selectAllUser() {
		// TODO Auto-generated method stub
		try {
			return sessionFactory.getCurrentSession().createQuery("from UserDetails").list();
		}
		catch(Exception e) {
			System.out.println(e.getMessage());
			return null;
	}
	}

	public UserDetails selectOneUser(int user_id) {
		// TODO Auto-generated method stub
		try {
			return (UserDetails)sessionFactory.getCurrentSession().createQuery("from UserDetails where u_id="+user_id).uniqueResult();
		}
		catch(Exception e) {
			System.out.println(e.getMessage());
			return null;
	}
	
	}

	
}
